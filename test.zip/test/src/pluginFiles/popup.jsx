import React, { useState } from "react";
import { token } from "./token";

export function TaskForm() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const repoOwner = 'zhenija';
  const repoName = 'myPlugin';

  const handleTitleChange = (event) => {
    setTitle(event.target.value);
  };

  const handleDescriptionChange = (event) => {
    setDescription(event.target.value);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
  
    const response = await fetch(`https://api.github.com/repos/${repoOwner}/${repoName}/issues`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/vnd.github.v3+json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        title,
        body: description,
      }),
    });
  
    if (response.ok) {
      alert("Task created successfully!");
      setTitle("");
      setDescription("");
    } else {
      alert("Failed to create task. Please try again.");
    }
  };
  
  return (
    <form
      onSubmit={handleSubmit}
      className='form'
    >
      <img alt="Git logo" src="gitLogo.png" className="form__logo"></img>
      <label className="form__label">
        Issue Title:
        <input 
          type="text" 
          value={title}
          onChange={handleTitleChange}
          className="form__input"
        />
      </label>

      <label className="form__label">
        Issue Description:
        <textarea
          value={description} 
          onChange={handleDescriptionChange}
          className="form__textarea"
        />
      </label>

      <button 
        type="submit"
        className="form__textarea"
      >
        Create Issue
      </button>
    </form>
  );
}
