import '../src/pluginFiles/popup.scss';
import { TaskForm } from './pluginFiles/popup.jsx';

function App() {

  return (
    <div className="App">
      <div id="popup-root">
        <TaskForm />
      </div>
    </div>
  );
}

export default App;
