/* global chrome */

chrome.commands.onCommand.addListener(function(command) {
  if (command === "create-task") {
    console.log("Create task command triggered.");
    chrome.action.setPopup({ popup: chrome.runtime.getURL("index.html") });
  }
});
